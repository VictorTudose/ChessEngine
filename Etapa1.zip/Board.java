public class Board {
	public static Board boardInstance = null;
	Piece[][] boardConf;
	Game.colors engineColor;

	// Board is a singleton

	private Board(Game.colors engineColor) {
		this.engineColor = engineColor;
		boardConf = new Piece[9][9];
		initBoard();
	}

	public static Board getBoardInstance(Game.colors engineColor) {
		if (boardInstance == null) {
			boardInstance = new Board(engineColor);
		}
		return boardInstance;
	}

	public void initBoard() {
		boardConf[1][1] = new Piece(Piece.pieceType.ROOK, Game.colors.WHITE, 1, 1);
		boardConf[1][2] = new Piece(Piece.pieceType.KNIGHT, Game.colors.WHITE, 2, 1);
		boardConf[1][3] = new Piece(Piece.pieceType.BISHOP, Game.colors.WHITE, 3, 1);
		boardConf[1][4] = new Piece(Piece.pieceType.QUEEN, Game.colors.WHITE, 4, 1);
		boardConf[1][5] = new Piece(Piece.pieceType.KING, Game.colors.WHITE, 5, 1);
		boardConf[1][6] = new Piece(Piece.pieceType.BISHOP, Game.colors.WHITE, 6, 1);
		boardConf[1][7] = new Piece(Piece.pieceType.KNIGHT, Game.colors.WHITE, 7, 1);
		boardConf[1][8] = new Piece(Piece.pieceType.ROOK, Game.colors.WHITE, 8, 1);
		for (int j = 1; j <= 8; j++) {
			boardConf[2][j] = new Pawn(Piece.pieceType.OPENINGPAWN, Game.colors.WHITE, j, 2);
			boardConf[7][j] = new Pawn(Piece.pieceType.OPENINGPAWN, Game.colors.BLACK, j, 7);
		}
		boardConf[8][1] = new Piece(Piece.pieceType.ROOK, Game.colors.BLACK, 1, 8);
		boardConf[8][2] = new Piece(Piece.pieceType.KNIGHT, Game.colors.BLACK, 2, 8);
		boardConf[8][3] = new Piece(Piece.pieceType.BISHOP, Game.colors.BLACK, 3, 8);
		boardConf[8][4] = new Piece(Piece.pieceType.QUEEN, Game.colors.BLACK, 4, 8);
		boardConf[8][5] = new Piece(Piece.pieceType.KING, Game.colors.BLACK, 5, 8);
		boardConf[8][6] = new Piece(Piece.pieceType.BISHOP, Game.colors.BLACK, 6, 8);
		boardConf[8][7] = new Piece(Piece.pieceType.KNIGHT, Game.colors.BLACK, 7, 8);
		boardConf[8][8] = new Piece(Piece.pieceType.ROOK, Game.colors.BLACK, 8, 8);
	}

	public void opponentMove(String move) {
		int[] mv = Utils.moveToPositions(move);
		if (boardConf[mv[3]][mv[2]] == null) {
			boardConf[mv[3]][mv[2]] = boardConf[mv[1]][mv[0]];
			boardConf[mv[1]][mv[0]] = null;
			boardConf[mv[3]][mv[2]].y = mv[3];
			boardConf[mv[3]][mv[2]].x = mv[2];
		}
	}

	public void makeMove(int oldX, int oldY, int newX, int newY) {

		
		if (boardConf[oldY][oldX] != null) {
			// conditii necesara pentru mutari de pioni in Force mode
			if (boardConf[oldY][oldX].type == Piece.pieceType.OPENINGPAWN) {
				boardConf[oldY][oldX].type = Piece.pieceType.PAWN;
			}

			// pawn promotion
			if ((newY == 8) && (boardConf[oldY][oldX].type == Piece.pieceType.PAWN)
					&& (boardConf[oldY][oldX].color == Game.colors.WHITE)) {
				boardConf[oldY][oldX].type = Piece.pieceType.QUEEN;
			}

			// pawn promotion
			if ((newY == 1) && (boardConf[oldY][oldX].type == Piece.pieceType.PAWN)
					&& (boardConf[oldY][oldX].color == Game.colors.BLACK)) {
				boardConf[oldY][oldX].type = Piece.pieceType.QUEEN;
			}

			boardConf[newY][newX] = boardConf[oldY][oldX];
			boardConf[oldY][oldX] = null;
			boardConf[newY][newX].y = newY;
			boardConf[newY][newX].x = newX;
			System.out.println(Utils.positionsToMove(oldX, oldY, newX, newY));

		}

	}

	public boolean possibleMove(int x, int y) {
		if ((y >= 1 && y <= 8) && (x >= 1 && x <= 8) && (boardConf[y][x] == null))
			return true;
		else
			return false;
	}

	public boolean attackMove(int x, int y) {
		if ((y >= 1 && y <= 8) && (x >= 1 && x <= 8) && (boardConf[y][x] != null)
				&& (boardConf[y][x].color != engineColor))
			return true;
		else
			return false;
	}

}