import java.io.*;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		InputStreamReader in = new InputStreamReader(System.in);

		BufferedReader input = new BufferedReader(in);

//		int array[] = Utils.moveToPositions("d7d6");
		String line = null;
		Game game = null;
//		long startingTime = 0, currentTime = 0;
		int pause = 0;
		int white = 0, black = 1;

		// imi aleg o piesa cu care fac mutari cat timp este posibil
		Piece blackPiece = null, whitePiece = null;
		while (true) {
			line = input.readLine();
			if (line.contains("protover 2")) {
				Utils.writeCommand("feature sigint=0");
			}

			if (line.contains("new")) {
				game = new Game(Board.getBoardInstance(Game.colors.BLACK), Game.states.GO, Game.colors.BLACK, Utils.fiveMinutes,
						Utils.fiveMinutes);

//				startingTime = System.currentTimeMillis();
//				currentTime = startingTime;
				// imi aleg un pion pe care o sa-l mut pana nu mai am mutare valida
				blackPiece = game.board.boardConf[7][2];
				whitePiece = game.board.boardConf[2][7];
			}

			if (line.contains("black")) {
				game.setColor(Game.colors.BLACK);
				pause = 1;
				white = 0;
				black = 1;
			}

			if (line.contains("white")) {
				game.setColor(Game.colors.WHITE);
				pause = 1;
				black = 0;
				white = 1;
			}

			if (line.contains("go")) {
				pause = 0;
//				currentTime = System.currentTimeMillis();
				if (white == 1) {
					boolean ok = Pawn.pawnMove(game.board, whitePiece);
					if ((ok == false) || (whitePiece == null))
						Utils.writeCommand("resign");
				} else {
					boolean ok = Pawn.pawnMove(game.board, blackPiece);
					if ((ok == false) || (blackPiece == null))
						Utils.writeCommand("resign");
				}
			}

			if (line.contains("quit"))
			{
				System.exit(0);
			}

			if (line.contains("force")) {

				int movesMadeInForceMode = 0;
				line = input.readLine();
				while ((!line.equals("go")) && (!line.contains("white")) && (!line.contains("black"))) {
					if (line.matches("^([a-h][1-8]+)+$")) {
						
						int[] move = Utils.moveToPositions(line);
						game.board.makeMove(move[0], move[1], move[2], move[3]);
						
						if (blackPiece == null) {
							blackPiece = game.board.boardConf[move[3]][move[2]];
						}
						if (whitePiece == null) {
							whitePiece = game.board.boardConf[move[3]][move[2]];
						}
						++movesMadeInForceMode;
					}
					line = input.readLine();
				}

				// daca s-a facut un nr impar de mutari in force mode engineul schimba culoarea
				// pe care joaca
				if (movesMadeInForceMode % 2 == 1) {
					game.changeColor();
				}
				game.setOpTime(Utils.fiveMinutes);
				game.setEngineTime(Utils.fiveMinutes);
			}

			if (line.contains("time")) {
				String[] aux = line.split(" ");
				game.setEngineTime(Long.parseLong(aux[1]));
			}

			if (line.contains("otim")) {
				String[] aux = line.split(" ");
				game.setOpTime(Long.parseLong(aux[1]));
			}

			if (line.matches("^([a-h][1-8]+)+$")) {
				// metoda actualizeaza board
				game.board.opponentMove(line);
				if (black == 1) {
					if (game.board.boardConf[blackPiece.y][blackPiece.x].color != blackPiece.color) {
						Utils.writeCommand("resign");
					}
					// metoda calculeaza mutare(cauta mutare valida, altfel da resign)
					boolean ok = Pawn.pawnMove(game.board, blackPiece);
					if (ok == false) {
						Utils.writeCommand("resign");
					}

				} else {
					if (game.board.boardConf[whitePiece.y][whitePiece.x].color != whitePiece.color) {
						Utils.writeCommand("resign");
					}
					// metoda calculeaza mutare(cauta mutare valida, altfel da resign)
					boolean ok = Pawn.pawnMove(game.board, whitePiece);
					if (ok == false) {
						Utils.writeCommand("resign");
					}
				}

			}

			if (game != null) {
				if (game.engineTime <= 0) {
					Utils.writeCommand("resign");
				}
			}

			if ((blackPiece!=null)&&(whitePiece!=null))
				System.out.println(blackPiece.y + " " + blackPiece.x);
		}
	}
}