public class Pawn extends Piece {

	boolean enPassantPossibilityLeft = true;
	boolean enPassantPossibilityRight = true;

	public Pawn(pieceType type, Game.colors color, int x, int y) {
		super(type, color, x, y);
	}

	// pot fi pioni langa pe liniile de en passant dar mutarea sa nu fie valida
	public static void enPassantIllusion(Board board, Pawn pwn) {

		if ((pwn.y == 4) && (pwn.color == Game.colors.BLACK)
				&& (board.attackMove(pwn.x - 1, pwn.y) || board.attackMove(pwn.x - 1, pwn.y - 1))) {
			pwn.enPassantPossibilityRight = false;
		}

		if ((pwn.y == 5) && (pwn.color == Game.colors.WHITE)
				&& (board.attackMove(pwn.x + 1, pwn.y) || board.attackMove(pwn.x + 1, pwn.y + 1))) {
			pwn.enPassantPossibilityRight = false;
		}

		if ((pwn.y == 4) && (pwn.color == Game.colors.BLACK)
				&& (board.attackMove(pwn.x + 1, pwn.y) || board.attackMove(pwn.x + 1, pwn.y - 1))) {
			pwn.enPassantPossibilityLeft = false;
		}

		if ((pwn.y == 5) && (pwn.color == Game.colors.WHITE)
				&& (board.attackMove(pwn.x - 1, pwn.y) || board.attackMove(pwn.x - 1, pwn.y + 1))) {
			pwn.enPassantPossibilityLeft = false;
		}
	}

	public static boolean openingPawnMove(Board board, Piece piece) {
		if (piece != null) {
			if (board.boardConf[piece.y][piece.x].color == Game.colors.BLACK) {
				// Cazuri in care pionul cucereste alta piesa
				if (board.attackMove(piece.x - 1, piece.y - 1) == true) {
					board.boardConf[piece.y][piece.x].type = Piece.pieceType.PAWN;
					board.makeMove(piece.x, piece.y, piece.x - 1, piece.y - 1);
					return true;
				}

				if (board.attackMove(piece.x + 1, piece.y - 1) == true) {
					board.boardConf[piece.y][piece.x].type = Piece.pieceType.PAWN;
					board.makeMove(piece.x, piece.y, piece.x + 1, piece.y - 1);
					return true;
				}

				// Cazuri in care pionul avanseaza
				if (board.possibleMove(piece.x, piece.y - 2) == true) {
					board.boardConf[piece.y][piece.x].type = Piece.pieceType.PAWN;
					board.makeMove(piece.x, piece.y, piece.x, piece.y - 2);
					return true;
				}

				if (board.possibleMove(piece.x, piece.y - 1) == true) {
					board.boardConf[piece.y][piece.x].type = Piece.pieceType.PAWN;
					board.makeMove(piece.x, piece.y, piece.x, piece.y - 1);
					return true;
				}
			} else {
				// Cazuri in care pionul cucereste alta piesa
				if (board.attackMove(piece.x - 1, piece.y + 1) == true) {
					board.boardConf[piece.y][piece.x].type = Piece.pieceType.PAWN;
					board.makeMove(piece.x, piece.y, piece.x - 1, piece.y + 1);
					return true;
				}

				if (board.attackMove(piece.x + 1, piece.y + 1) == true) {
					board.boardConf[piece.y][piece.x].type = Piece.pieceType.PAWN;
					board.makeMove(piece.x, piece.y, piece.x + 1, piece.y + 1);
					return true;
				}

				// Cazuri in care pionul avanseaza
				if (board.possibleMove(piece.x, piece.y + 2) == true) {
					board.boardConf[piece.y][piece.x].type = Piece.pieceType.PAWN;
					board.makeMove(piece.x, piece.y, piece.x, piece.y + 2);
					return true;
				}

				if (board.possibleMove(piece.x, piece.y + 1) == true) {
					board.boardConf[piece.y][piece.x].type = Piece.pieceType.PAWN;
					board.makeMove(piece.x, piece.y, piece.x, piece.y + 1);
					return true;
				}
			}
			// nu a reusit sa faca miscare
			return false;
		}
		// piesa e null
		return false;
	}

	public static boolean basicPawnMove(Board board, Piece piece) {
		if (piece != null) {
			if (board.boardConf[piece.y][piece.x].color == Game.colors.BLACK) {
				// Cazuri in care pionul cucereste alta piesa
				if (board.attackMove(piece.x - 1, piece.y - 1) == true) {
					board.makeMove(piece.x, piece.y, piece.x - 1, piece.y - 1);
					enPassantIllusion(board, (Pawn) board.boardConf[piece.y][piece.x]);

					// daca a promovat in regina, dam resign
					if (piece.y == 1) {
						board.boardConf[piece.y][piece.x].type = Piece.pieceType.QUEEN;
						return false;
					}
					return true;
				}

				if (board.attackMove(piece.x + 1, piece.y - 1) == true) {
					board.makeMove(piece.x, piece.y, piece.x + 1, piece.y - 1);
					enPassantIllusion(board, (Pawn) board.boardConf[piece.y][piece.x]);

					// daca a promovat in regina, dam resign
					if (piece.y == 1) {
						board.boardConf[piece.y][piece.x].type = Piece.pieceType.QUEEN;
						return false;
					}
					return true;
				}

				// Cazuri EN PASSANT
				if ((piece.y == 4) && (board.attackMove(piece.x + 1, piece.y) == true)
						&& ((Pawn) piece).enPassantPossibilityLeft) {
					board.makeMove(piece.x, piece.y, piece.x + 1, piece.y - 1);
					board.boardConf[piece.y][piece.x + 1] = null;
					return true;
				}

				if ((piece.y == 4) && (board.attackMove(piece.x - 1, piece.y) == true)
						&& ((Pawn) piece).enPassantPossibilityRight) {
					board.makeMove(piece.x, piece.y, piece.x - 1, piece.y - 1);
					board.boardConf[piece.y][piece.x - 1] = null;
					return true;
				}

				// Cazuri in care pionul avanseaza
				if (board.possibleMove(piece.x, piece.y - 1) == true) {
					board.makeMove(piece.x, piece.y, piece.x, piece.y - 1);
					enPassantIllusion(board, (Pawn) board.boardConf[piece.y][piece.x]);

					// daca a promovat in regina, dam resign
					if (piece.y == 1) {
						board.boardConf[piece.y][piece.x].type = Piece.pieceType.QUEEN;
						return false;
					}
					return true;
				}
			} else {
				System.out
						.println("ROMANIA EUROVISION " + piece.y + " ROXEN " + piece.x + " JAJJA " + board.engineColor);

				// Cazuri in care pionul cucereste alta piesa
				if (board.attackMove(piece.x - 1, piece.y + 1) == true) {
					board.makeMove(piece.x, piece.y, piece.x - 1, piece.y + 1);
					enPassantIllusion(board, (Pawn) board.boardConf[piece.y][piece.x]);

					// daca a promovat in regina, dam resign
					if (piece.y == 8) {
						board.boardConf[piece.y][piece.x].type = Piece.pieceType.QUEEN;
						return false;
					}
					return true;
				}

				if (board.attackMove(piece.x + 1, piece.y + 1) == true) {
					board.makeMove(piece.x, piece.y, piece.x + 1, piece.y + 1);
					enPassantIllusion(board, (Pawn) board.boardConf[piece.y][piece.x]);

					// daca a promovat in regina, dam resign
					if (piece.y == 8) {
						board.boardConf[piece.y][piece.x].type = Piece.pieceType.QUEEN;
						return false;
					}
					return true;
				}

				// Cazuri EN PASSANT
				if ((piece.y == 5) && (board.attackMove(piece.x + 1, piece.y) == true)
						&& ((Pawn) piece).enPassantPossibilityRight) {
					board.makeMove(piece.x, piece.y, piece.x + 1, piece.y + 1);
					board.boardConf[piece.y][piece.x + 1] = null;
					return true;
				}

				if ((piece.y == 5) && (board.attackMove(piece.x - 1, piece.y) == true)
						&& ((Pawn) piece).enPassantPossibilityLeft) {
					board.makeMove(piece.x, piece.y, piece.x - 1, piece.y + 1);
					board.boardConf[piece.y][piece.x - 1] = null;
					return true;
				}

				// Cazuri in care pionul avanseaza
				if (board.possibleMove(piece.x, piece.y + 1) == true) {
					board.makeMove(piece.x, piece.y, piece.x, piece.y + 1);
					enPassantIllusion(board, (Pawn) board.boardConf[piece.y][piece.x]);

					// daca a promovat in regina, dam resign
					if (piece.y == 8) {
						board.boardConf[piece.y][piece.x].type = Piece.pieceType.QUEEN;
						return false;
					}
					return true;
				}
			}
			// nu a reusit sa faca miscare
			return false;
		}
		// piesa e null
		return false;
	}

	public static boolean pawnMove(Board board, Piece piece) {
		if (piece.type == Piece.pieceType.OPENINGPAWN) {
			return openingPawnMove(board, piece);
		}
		return basicPawnMove(board, piece);
	}

}
